####################################################################################
##                                                                                ## 
##                             Data Analysis Job                                  ##  
##                                                                                ## 
####################################################################################
rm(list = ls())  ## 清空工作目录

############# 设置工作路径****
## 请使用setwd函数，设置自己的工作路径，并将上述所提到的文件放到该工作路径下***
## setwd(.....)

## package: readxl  用于读取Excel文件
## package: ggplot2 用于绘制各类图表
## package: jiebaR 用于分词
library(readxl)
library(ggplot2)
library(jiebaR)

options(scipen = 200)  ## 去除科学计数法

jobinfo = read_excel("jobinfo.xlsx")   ## 读取原始数据

str(jobinfo)  ## 查看数据结构
jobinfo$最低薪资 = as.numeric(jobinfo$最低薪资)  ## 将最低薪资的字符型变量改为数值型变量
jobinfo$最高薪资 = as.numeric(jobinfo$最高薪资)  ## 将最高薪资的字符型变量改为数值型变量

## 图片颜色设置，利用rgb函数产生颜色，用于后续画图使用
col1 = rgb(32,40,51,maxColorValue = 255)   ##某一种黑色
col2 = rgb(172,22,34,maxColorValue = 255)  ##某一种深红
col3 = "indianred " ##某一种浅红
col4 = "dimgrey"   ##某一种灰色

###################### 平均薪资影响因素分析

## 在jobinfo中创建对数平均薪资的变量（去除异方差等影响）
jobinfo$对数平均薪资 = log((jobinfo$最高薪资+jobinfo$最低薪资)/2)

#### 薪资整体情况
## 利用ggplot2中的ggplot画出对数平均薪资直方图
##### mac代码段
ggplot(data = jobinfo,aes(x=对数平均薪资)) +
        geom_histogram(binwidth = 0.3,fill=col4,colour=col1) +
        labs(y="频数") +
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(data = jobinfo,aes(x=对数平均薪资)) +
        geom_histogram(binwidth = 0.3,fill=col4,colour=col1) +
        labs(y="频数")

## 求出各地区的对数平均薪资的中位数
district = unique(jobinfo$地区)
beijing.med = median(jobinfo$对数平均薪资[jobinfo$地区=="北京"],na.rm = TRUE)
hebei.med = median(jobinfo$对数平均薪资[jobinfo$地区=="河北"],na.rm = TRUE)
shanxi1.med = median(jobinfo$对数平均薪资[jobinfo$地区=="山西"],na.rm = TRUE)
shanxi3.med = median(jobinfo$对数平均薪资[jobinfo$地区=="陕西"],na.rm = TRUE)
shanghai.med = median(jobinfo$对数平均薪资[jobinfo$地区=="上海"],na.rm = TRUE)
shenzhen.med = median(jobinfo$对数平均薪资[jobinfo$地区=="深圳"],na.rm = TRUE)
## 将各地区的median合并到district.med
district.med = c(beijing.med,hebei.med,shanxi1.med,shanxi3.med,shanghai.med,shenzhen.med)
## 将地区按median从小到大排列
district = district[order(district.med)]
## 按照disctrict向量将地区重新划分为以district向量为level的因子向量
jobinfo$地区 = factor(jobinfo$地区,levels = district)

#### 地区对薪资的影响
## 利用箱线图画出，薪资vs地区的分布，箱体的宽度越宽表示样本量越多
##### mac代码段
ggplot(jobinfo,aes(地区,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,col4,col3,col3,col3)) + 
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo,aes(地区,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,col4,col3,col3,col3))

#### 公司类别对薪资的影响
## 利用箱线图画出，薪资vs公司类别的分布，箱体的宽度越宽表示样本量越多
##### mac代码段
ggplot(jobinfo,aes(公司类别,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = col4) + 
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo,aes(公司类别,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = col4)

#### 公司规模对薪资的影响
## 利用箱线图画出，公司规模vs公司类别的分布，箱体的宽度越宽表示样本量越多
## 将公司规模转化为因子型变量，便于画图
jobinfo$公司规模 = factor(jobinfo$公司规模,levels=c("少于50人","50-150人","150-500人","500-1000人","1000-5000人","5000-10000人","10000人以上"))
##### mac代码段
ggplot(jobinfo,aes(公司规模,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = col4) + 
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo,aes(公司规模,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = col4)

#### 要求经验对薪资的影响
## 我们将经验划分为区间进行处理，无经验要求，1-2年，3-4年，5-6年，7-8年，9-10年
## 在jobinfo中创建新的变量，名为经验区间，来存储以上区间
jobinfo$经验区间[jobinfo$经验==0] = "无经验要求"
jobinfo$经验区间[jobinfo$经验==1|jobinfo$经验==2] = "1-2年"
jobinfo$经验区间[jobinfo$经验==3|jobinfo$经验==4] = "3-4年"
jobinfo$经验区间[jobinfo$经验==5|jobinfo$经验==6] = "5-6年"
jobinfo$经验区间[jobinfo$经验==7|jobinfo$经验==8] = "7-8年"
jobinfo$经验区间[jobinfo$经验==9|jobinfo$经验==10] = "9-10年"
## 将经验区间转化为因子型变量，便于画图
jobinfo$经验区间 = factor(jobinfo$经验区间,levels=c("无经验要求","1-2年","3-4年","5-6年","7-8年","9-10年"))

## 利用箱线图画出，经验区间vs公司类别的分布，箱体的宽度越宽表示样本量越多
##### mac代码段
ggplot(jobinfo,aes(经验区间,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,"bisque3","bisque3","indianred","indianred")) + 
        labs(x="工作经验要求") +
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo,aes(经验区间,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,"bisque3","bisque3","indianred","indianred")) + 
        labs(x="工作经验要求")


#### 学历对薪资的影响
## 利用箱线图画出，学历vs公司类别的分布，箱体的宽度越宽表示样本量越多
## 将学历转化为因子型变量，便于画图
jobinfo$学历 = factor(jobinfo$学历,levels=c("中专","高中","大专","无","本科","硕士","博士"))
##### mac代码段
ggplot(jobinfo,aes(学历,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,col4,col4,"bisque3","bisque3",col3)) + 
        labs(x="学历要求")+
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo,aes(学历,对数平均薪资)) + 
        geom_boxplot(varwidth = TRUE, fill = c(col4,col4,col4,col4,"bisque3","bisque3",col3)) + 
        labs(x="学历要求")


############ 统计软件分析

##### 匹配各个公司要求的统计软件

## 首先建立software数据框，用于存放各个公司的软件匹配结果
software = as.data.frame(matrix(0,nrow = length(jobinfo$描述), ncol = 12))  ## 先建立一个0矩阵，行数为观测数，列数为统计软件的个数，并转化为data frame格式
colnames(software) = c("R","SPSS","Excel","Python","MATLAB","Java","SQL","SAS","Stata","EViews","Spark","Hadoop")  ## 将software的data frame的列名改为软件名称

mixseg = worker() ##  按照缺省值，设置分词引擎

## 对每个描述观测进行分词，并存储在software里面，循环次数为总观测数，总观测数可通过length(jobinfo$描述)获取
for (j in 1:length(jobinfo$描述)){
        
        subdata = as.character(jobinfo$描述[j])  ## 取出每个观测，保存在subdata变量
        fenci = mixseg[subdata]  ##对取出的观测进行分词，保存在分词变量
        
        ## 设置各个软件的判别条件，以R为例, R.indentify表示r或R是否在fenci这个变量里
        R.identify = ("R" %in% fenci) | ("r" %in% fenci)
        SPSS.identify = ("spss" %in% fenci) | ("Spss" %in% fenci) | ("SPSS" %in% fenci)
        Excel.identify = ("excel" %in% fenci) | ("EXCEL" %in% fenci) | ("Excel" %in% fenci)
        Python.identify = ("Python" %in% fenci) | ("python" %in% fenci) | ("PYTHON" %in% fenci)
        MATLAB.identify = ("matlab" %in% fenci) | ("Matlab" %in% fenci) | ("MATLAB" %in% fenci)
        Java.identify = ("java" %in% fenci) | ("JAVA" %in% fenci) | ("Java" %in% fenci)
        SQL.identify = ("SQL" %in% fenci) | ("Sql" %in% fenci) | ("sql" %in% fenci)
        SAS.identify = ("SAS" %in% fenci) | ("Sas" %in% fenci) | ("sas" %in% fenci)
        Stata.identify = ("STATA" %in% fenci) | ("Stata" %in% fenci) | ("stata" %in% fenci)
        EViews.identify = ("EViews" %in% fenci) | ("EVIEWS" %in% fenci) | ("Eviews" %in% fenci) | ("eviews" %in% fenci) 
        Spark.identify = ("Spark" %in% fenci) | ("SPARK" %in% fenci) | ("spark" %in% fenci)
        Hadoop.identify = ("HADOOP" %in% fenci) | ("Hadoop" %in% fenci) | ("hadoop" %in% fenci)
        
        ## 判断各个描述变量里面是否有某软件要求，以R为例，第j个描述变量，若R.identify为TRUE时，
        ## software的第j行的R变量为1，反之为0；1表示有要求，0表示无要求
        if (R.identify) software$R[j] = 1
        if (SPSS.identify) software$SPSS[j] = 1
        if (Excel.identify) software$Excel[j] = 1
        if (Python.identify) software$Python[j] = 1
        if (MATLAB.identify) software$MATLAB[j] = 1
        if (Java.identify) software$Java[j] = 1
        if (SQL.identify) software$SQL[j] = 1
        if (SAS.identify) software$SAS[j] = 1
        if (Stata.identify) software$Stata[j] = 1
        if (EViews.identify) software$EViews[j] = 1
        if (Spark.identify) software$Spark[j] = 1
        if (Hadoop.identify) software$Hadoop[j] = 1
}

## 将对数平均薪资和software这两个数据框合并
jobinfo.new = cbind(jobinfo$对数平均薪资,software)
colnames(jobinfo.new) = c("对数平均薪资",colnames(software))

#### 以SQL为例，比较是否掌握SQL技能对对数平均薪资的影响
##### mac代码段
ggplot(jobinfo.new,aes(as.factor(SQL),对数平均薪资)) + 
        geom_boxplot(fill = c(col4,col3)) + 
        labs(x="是否要求会使用SQL") +
        theme(text = element_text(family = "STKaiti", size = 20))
##### win代码段
ggplot(jobinfo.new,aes(as.factor(SQL),对数平均薪资)) + 
        geom_boxplot(fill = c(col4,col3)) + 
        labs(x="是否要求会使用SQL")

save(jobinfo,jobinfo.new,file = "temp.rda")
