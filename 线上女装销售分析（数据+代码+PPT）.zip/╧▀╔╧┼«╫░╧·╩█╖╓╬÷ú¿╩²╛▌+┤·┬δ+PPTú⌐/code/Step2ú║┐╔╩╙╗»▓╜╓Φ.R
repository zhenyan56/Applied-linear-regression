########################################################
#######################可视化步骤#######################
########################################################
####制作可视化数据集####
library(grid)
library(ggplot2)
lgdata3<-data.frame(sales=(log(salesold)),price=log(totalold[,6]), #构建数据集
                    是否韩版=factor(as.numeric(sapply(facseg,hanban))),#将商品名中包含'韩版'的商品标记为1，其它为0，构建向量
                    是否新款=factor(as.numeric(sapply(facseg,xinkuan))),#将商品名中包含'新款'的商品标记为1，其他为0
                    是否显瘦=factor(as.numeric(sapply(facseg,xianshou))),#同上
                    是否中长款=factor(as.numeric(sapply(facseg,zhongchang))),#同上
                    是否修身=factor(as.numeric(sapply(facseg,xiushen))),#同上
                    miaoshu=factor(totalold[,10]),#将原来的总数据集中的描述评分以因子形式合并进入数据集
                    fuwu=factor(totalold[,11]),wuliu=factor(totalold[,12]), #同理将服务 和 物流评分合并
                    old=facold) #将适用年龄 这一属性合并入数据集

#####为了将数据集中的0-1的因子变量转化为 ‘否’-‘是’ 方便可视化的可读性#####
#构造将0,1转化为是否的函数#
shi<-function(x){
  k<-which(x==1)
  m[k]<-'是'
  k0<-which(x==0)
  m[k0]<-'否'
  return (m)
}

###把数据集中的3-7列的0-1变量全都变成'是''否'###
lgdata3[,3]<-factor(as.character(shi(lgdata3[,3])))
lgdata3[,4]<-factor(as.character(shi(lgdata3[,4])))
lgdata3[,5]<-factor(as.character(shi(lgdata3[,5])))
lgdata3[,6]<-factor(as.character(shi(lgdata3[,6])))
lgdata3[,7]<-factor(as.character(shi(lgdata3[,7])))

#####开始绘图#####
#1.销量整体的histogram#
sales<-sales[-sales<100]    #去除不关心的低销量商品
##通过划分不同的销量区间，将销量这个“连续型数据”转化为“离散型数据”##
salestable<-data.frame(table(cut(sales,breaks=c(100*(1:5),150,250,1000,3000),
                                 labels=c('100-150','150-200','200-250','250-300','300-400',
                                          '400-500','500-1000',' >1000')))) #通过table函数来统计不同区间内的商品个数数量
##使用ggplot2的绘图语法开始绘图
p<-ggplot(salestable,aes(x=reorder(Var1,rep(1,length(Var1)),sum),y = Freq)) #定位要绘制的数据框和关心的变量
p<-p+geom_bar(stat='identity',fill='darkolivegreen3',width=0.35)            #选择绘图形式(条形图),设定填充颜色，宽度等参数
p<-p+labs(x='月销量(笔)',y="商品数量(件)",title='连衣裙销售量的分布')+      #修改坐标轴图例
  theme(text=element_text(family="STKaiti",size=14))                        #选择中文输出格式和字体以及大小，否则可能会无法显示中文
p   #输出图像

#2.用ggplot2绘制boxplot（箱线图）  价格-销量
cprice<-cut(price,breaks=c(100*(0:5),5000),              #同1.1，将价格这一连续变量离散化
            labels=c('0-100','100-200','200-300',        #并设定分割标签
             '300-400','400-500','>500'))
cbox<-data.frame(cprice,sales=log(sales))                #构建用于绘图的数据框 价格区间-对数销量

p<-ggplot(cbox,aes(x=cprice,y=sales))                    #定位绘图数据集，选择关心的变量
p+geom_boxplot(fill='darkgoldenrod2',varwidth=T)+        #同上绘图语句第3条，varwidth=T 让箱子的宽度代表改组的样本个数，越宽越多
  theme(text=element_text(family="STKaiti",size=14))+    #选择中文的输出格式，设置字体字号
  labs(x='商品价格(元)',y='对数销售量',title="商品价格对销量的影响") #设置中文坐标轴标签和标题


#3.用ggplot2来画boxplot(箱线图)，年龄-销量
p<-ggplot(lgdata3,aes(x=old,y=sales))                                 #定位绘制的数据集和关心的坐标
p+geom_boxplot(varwidth=T,fill='darkolivegreen3')+                    #基本同上图第二条，varwidth=T让箱子的宽度代表属于该变量的样本个数
  theme(text=element_text(family="STKaiti",size=14))+                 #选择中文输出格式，调整绘图中出现的文本字体和大小
  labs(x='适用年龄',y='对数销售量',title="不同适用年龄对销量的影响")  #修改标题和坐标轴的名称

#4.Boxplot (显瘦) 年龄-销量
p<-ggplot(lgdata3,aes(x=as.factor(是否显瘦),y=(sales)))+     #同上
        geom_boxplot(aes(fill=是否显瘦))                     #同上，fill=是否显瘦是指在同一年龄层下，按照是否显瘦分为两个箱子
p<-p+labs(x='全部年龄段',y='',title='是否显瘦对销量的影响')
p<-p+theme(text=element_text(family="STKaiti",size=14))
p<-p+coord_flip()+scale_fill_manual(values = c('mistyrose4','darkolivegreen3'))+ #coord_flip 将坐标轴横过来
  theme(legend.position='none');                            # scale..为了调整不同箱子的填充颜色
#最后一句去掉一个图例。读者可以自行删去来查看变化，记得删去倒数第二行最后的加号

xianshou1<-lgdata3[as.numeric(lgdata3[,11])==3, ]          #根据数据集中的年龄属性，选择出我们认为最有明显不同的年龄层，作为子数据集
q<-ggplot(xianshou1,aes(x=as.factor(是否显瘦),y=(sales)))+ #然后根据新的子数据集来绘图，步骤同上，如法炮制。
       geom_boxplot(aes(fill=是否显瘦))
q<-q+labs(x='25-29周岁年龄段',y='对数销售量')
q<-q+theme(text=element_text(family="STKaiti",size=14))
q<-q+coord_flip()+scale_fill_manual(values = c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');

grid.newpage()         #展开新的画布，我们为了将两个ggplot2的图形在一张画布上呈现                          
pushViewport(viewport(layout = grid.layout(2, 1)))  #将画布分割成 2行，1列 2X1
vplayout = function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))      # 在画布上1,1的位置绘制第一个Boxplot
print(q, vp = vplayout(2, 1))      # 在画布上2,1的位置绘制第二个Boxplot
#建议，该段落为一整套的ggplot一页多图的模板语法，了解其作用即可。

#5.boxplot   新款 年龄层次-销量
p<-ggplot(lgdata3,aes(x=是否新款,y=sales))+geom_boxplot(aes(fill=是否新款)) #基本同上，读者可以对比差异加深理解。
p<-p+labs(x='全部年龄层',y='',title='是否新款对销量的影响')
p<-p+theme(text=element_text(family="STKaiti",size=14))
p<- p+  scale_colour_hue("what does it eat?",breaks=c("herbi","carni"),
                         labels=c("plants","meat"));
p<-p+coord_flip()+scale_fill_manual(values = c('mistyrose4','darkolivegreen3'))+
  theme(legend.position='none');

xinkuan1<-lgdata3[as.numeric(lgdata3[,11])==3, ]
q<-ggplot(xinkuan1,aes(x=as.factor(是否新款),y=(sales)))+geom_boxplot(aes(fill=是否新款))
q<-q+labs(x='25-29周岁年龄段',y='')
q<-q+theme(text=element_text(family="STKaiti",size=14))
q<-q+coord_flip()+scale_fill_manual(values = c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');
xinkuan2<-lgdata3[as.numeric(lgdata3[,11])==5, ]
q2<-ggplot(xinkuan2,aes(x=as.factor(是否新款),y=(sales)))+
  geom_boxplot(aes(fill=是否新款))
q2<-q2+labs(x='35-39周岁年龄段',y='对数销售量')
q2<-q2+theme(text=element_text(family="STKaiti",size=14))
q2<-q2+coord_flip()+scale_fill_manual(values = c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');

grid.newpage()
pushViewport(viewport(layout = grid.layout(3, 1)))
vplayout = function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))
print(q, vp = vplayout(2, 1))
print(q2,vp=vplayout(3,1))


#6.boxplot 中长款服饰  年龄-销量
p<-ggplot(lgdata3,aes(x=是否中长款,y=(sales)))+geom_boxplot(aes(fill=是否中长款)) #基本同上
p<-p+labs(x='全部年龄层',y='',title='是否中长款对销量的影响')
p<-p+theme(text=element_text(family="STKaiti",size=14))
p<-p+coord_flip()+scale_fill_manual(values = c('mistyrose4','darkolivegreen3'))+
  theme(legend.position='none');
zhongchang1<-lgdata3[as.numeric(lgdata3[,11])==2, ]
q<-ggplot(zhongchang1,aes(x=as.factor(是否中长款),y=(sales)))+geom_boxplot(aes(fill=是否中长款))
q<-q+labs(x='18-24周岁年龄段',y='')
q<-q+theme(text=element_text(family="STKaiti",size=14))
q<-q+coord_flip()+scale_fill_manual(values=c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');
zhongchang2<-lgdata3[as.numeric(lgdata3[,11])==6, ]
q2<-ggplot(zhongchang2,aes(x=是否中长款,y=(sales)))+geom_boxplot(aes(fill=是否中长款))
q2<-q2+labs(x='40-49周岁年龄段',y='对数销售量')
q2<-q2+theme(text=element_text(family="STKaiti",size=14))
q2<-q2+coord_flip()+scale_fill_manual(values=c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');

grid.newpage()
pushViewport(viewport(layout = grid.layout(3, 1)))
vplayout = function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))
print(q, vp = vplayout(2, 1))
print(q2,vp=vplayout(3,1))

#7.boxplot 韩版 年龄-销量 
p<-ggplot(lgdata3,aes(x=是否韩版,y=sales))+         #基本同上，读者可自行寻找差异来加深理解。
  geom_boxplot(aes(fill=是否韩版))
p<-p+labs(x='全部年龄层',y='',title="是否韩版对销量的影响")
p<-p+theme(text=element_text(family="STKaiti",size=14))
p<-p+coord_flip()+scale_fill_manual(values = c('mistyrose4','darkolivegreen3'))+
  theme(legend.position='none');

hanban1<-lgdata3[as.numeric(lgdata3[,11])==2, ]
q1<-ggplot(hanban1,aes(x=as.factor(是否韩版),y=(sales)))+geom_boxplot(aes(fill=是否韩版))
q1<-q1+labs(x='18-24周岁年龄段',y='对数销售量')
q1<-q1+theme(text=element_text(family="STKaiti",size=14))
q1<-q1+coord_flip()+scale_fill_manual(values = c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');

hanban2<-lgdata3[as.numeric(lgdata3[,11])==5, ]
q2<-ggplot(hanban2,aes(x=as.factor(是否韩版),y=(sales)))+geom_boxplot(aes(fill=是否韩版))
q2<-q2+labs(x='35-39周岁年龄段',y='')
q2<-q2+theme(text=element_text(family="STKaiti",size=14))
q2<-q2+coord_flip()+scale_fill_manual(values = c('darkgoldenrod2','darkolivegreen3'))+
  theme(legend.position='none');

grid.newpage()
pushViewport(viewport(layout = grid.layout(3, 1)))
vplayout = function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))
print(q2, vp = vplayout(2, 1))
print(q1,vp=vplayout(3,1))

#########################
#####开始考虑地区########
#########################
##使用正则语句提取关键词##  
#正则语句是负责文本字符提取的在多种语言中的通用语句。可在网络上搜索自行了解。
place<-substr(total[,14],regexpr('所在地区',total[,14]),     #通过定位‘所在地区’，在商品描述的文本中进行提取
              regexpr('所在地区',total[,14])+10)             #并且提取出‘所在地区：XXX'这一格式。
lll<-substr(place,regexpr('：',place)+1,regexpr('\n',place)-1) #把提取出的所在地区进行处理，保留市的名称
l1<-sub('市','',lll)                 #为了同一，有的信息中没有‘市’字，所以全部去掉‘市’

dlll<-data.frame(table(l1))           #这一段目的保留拥有商家较多的地点
dlll[,2]<-log(dlll[,2])
dlll<-dlll[dlll[,2]>0.5,];dlll<-dlll[-1,]
dplace<-dlll[which(dlll[,2]>4),1]

lgdata5<-data.frame(sales)            #构建地点和销量的数据集
for (i in 1:length(dplace)){          
  k<-grep(as.character(dplace[i]),total[,14])   #构造地点向量，读者可输出结果来查看形式。
  lgdata5[k,2]<-rep(dplace[i],length(k))
}
ina<-is.na(lgdata5[,2])
lgdata5<-lgdata5[-which(ina),]        #去掉缺失值，因为有些商家数量少的地点我们没有考虑。

kkk<-tapply(lgdata5[,1],lgdata5[,2],median,na.rm=T)  #该段落，目的是为了对后面的地点销量图
kkk<-kkk[-which(is.na(kkk))]                         #进行一些美观上的微调，诸如按照中位数大小排列
kkk<-kkk[kkk>149]                                    #而进行的语句，可以忽略。
rmwhat<-c(which(lgdata5[,2]=='郑州 '),
          which(lgdata5[,2]=='南京 '))
lgdata5<-lgdata5[-rmwhat,]
lgdata5[,2]<-factor(lgdata5[,2],levels=names(sort(kkk)),ordered=T)

#8.boxplot   地点-销量
p<-ggplot(lgdata5,aes(y=log(sales),x=V2))+                #同我们的主要绘图语句。可参考前文
  geom_boxplot(fill='darkolivegreen3',varwidth=T)
p<-p+labs(x='商家所在地',y='对数销售量',title="商家地点对销量的影响")
p<-p+theme(text=element_text(family="STKaiti",size=14))
p+coord_flip()


####几年店 开店时间的影响####       
t6<-grep('6年店',total[,14])     #提取6年店的商家的序号
t5<-grep('5年店',total[,14])
t4<-grep('4年店',total[,14])
t3<-grep('3年店',total[,14])
t2<-grep('2年店',total[,14])
t1<-grep('1年店',total[,14])
lgdata4<-data.frame(sales)      #构建数据集
unyear<-sales[-c(t3,t4,t5,t6)]  #将0-2年店的序号合并
years<-c('0-2年店','2年店','3年店','4年店','5年店','6年店')
lgdata4[(1:length(sales))[-c(t3,t4,t5,t6)],2]<-years[1]
lgdata4[t3,2]<-years[3]
lgdata4[t4,2]<-years[4]         #将数据框的第二列，定位生成年份的向量
lgdata4[t5,2]<-years[5]
lgdata4[t6,2]<-years[6]
店家成立时间<-lgdata4[,2]
lgdata4[,2]<-店家成立时间

#9. boxplot  时间-销量
p<-ggplot(lgdata4,aes(y=log(sales),x=V2))+geom_boxplot(fill='darkgoldenrod2')
p<-p+labs(x='店家年数',y='对数销售量',title="店家成立时间对销量的影响")
p<-p+theme(text=element_text(family="STKaiti",size=14))
p+coord_flip()

#######10.评分的箱线图#######
###关于物流描述服务的箱线图  （后面代码的注释类似）
ansales<-sales[-which(is.na(total[,12]))]    #删去没有物流评分的商品
anwuliu<-total[-which(is.na(total[,12])),12] #将物流评分因子化
anwuliu[anwuliu<4.7]<-'4.6及以下'            #将4.6以下的评分（含）合并到一起
an<-data.frame(wuliu=factor(as.character(anwuliu)),sales=log(ansales))

#绘图，同前
p<-ggplot(an,aes(x=wuliu,y=sales))+geom_boxplot(varwidth=T,fill='darkolivegreen3')
p<-p+labs(x='物流评分',y='',title='商品评价对销量的影响')
p<-p+coord_flip()+theme(text=element_text(family="STKaiti",size=14))

###关于物流描述服务的箱线图
ansales1<-sales[-which(is.na(total[,11]))]   
anfuwu<-total[-which(is.na(total[,11])),11]  
anfuwu[anfuwu<4.7]<-'4.6及以下'
an1<-data.frame(fuwu=factor(as.character(anfuwu)),sales=log(ansales1))


p1<-ggplot(an1,aes(x=fuwu,y=sales))+geom_boxplot(varwidth=T,fill='darkolivegreen3')
p1<-p1+labs(x='服务评分',y='')
p1<-p1+coord_flip()+theme(text=element_text(family="STKaiti",size=14))+scale_fill_manual(values = c('tomato2'))


###关于物流描述服务的箱线图
ansales<-sales[-which(is.na(total[,10]))]
anmiaoshu<-total[-which(is.na(total[,10])),10]
anmiaoshu[anmiaoshu<4.7]<-'4.6及以下'
an2<-data.frame(miaoshu=as.character(anmiaoshu),sales=log(ansales))


p2<-ggplot(an2,aes(x=miaoshu,y=sales))+geom_boxplot(varwidth=T,fill='darkolivegreen3')
p2<-p2+labs(x='描述评分',y='对数销售量')
p2<-p2+coord_flip()+theme(text=element_text(family="STKaiti",size=14))

grid.newpage()   #一页多图，同前
pushViewport(viewport(layout = grid.layout(3,1)))
vplayout = function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
print(p, vp = vplayout(1, 1))
print(p1, vp = vplayout(2, 1))
print(p2,vp=vplayout(3,1))


#####回归交互项系数的解读图########
attach(lgdata3)
o1<-which(as.numeric(old)==1)     #将不同年龄提取出来
o2<-which(as.numeric(old)==2)
o3<-which(as.numeric(old)==3)
o4<-which(as.numeric(old)==4)
o5<-which(as.numeric(old)==5)
o6<-which(as.numeric(old)==6)

lgo1<-lgdata3[o1,];lgo2<-lgdata3[o2,];lgo3<-lgdata3[o3,];  #根据不同年龄形成不同子数据集
lgo4<-lgdata3[o4,];lgo5<-lgdata3[o5,];
lgo6<-lgdata3[o6,];

odiff<-c(diff(tapply(lgo1[,1],lgo1[,3],median)),     #在不同的子数据集中，按照是否具有显瘦特性分类
         diff(tapply(lgo2[,1],lgo2[,3],median)),     #计算是否显瘦销量的差异，并且生成向量
         diff(tapply(lgo3[,1],lgo3[,3],median)),
         diff(tapply(lgo4[,1],lgo4[,3],median)),
         diff(tapply(lgo5[,1],lgo5[,3],median)),
         diff(tapply(lgo6[,1],lgo6[,3],median))
)
odiff2<-c(diff(tapply(lgo1[,1],lgo1[,5],median)),    #同理，针对韩版这一特点。
  diff(tapply(lgo2[,1],lgo2[,5],median)),
  diff(tapply(lgo3[,1],lgo3[,5],median)),
  diff(tapply(lgo4[,1],lgo4[,5],median)),
  diff(tapply(lgo5[,1],lgo5[,5],median)),
  diff(tapply(lgo6[,1],lgo6[,5],median)))
odiff<-as.data.frame(odiff)
odiff[,2]<-as.character(levels(old))      #构建我们新的绘图数据集
odiff2<-as.data.frame(odiff2)
odiff2[,2]<-as.character(levels(old))

#绘图，注释同前
p<-ggplot(odiff,aes(x=V2,y=odiff-1))
p<-p+geom_bar(stat='identity',fill='darkgoldenrod2')+
  labs(x='年龄段',y='韩版销量与非韩版销量之比',
       title='是否韩版在每个年龄层的销量比值')+
  theme(text=element_text(family="STKaiti",size=14))
p +scale_y_continuous(limits=c(-0.2, 0.8),breaks=c(-0.2,0,0.2,0.4,0.6,0.8),
                      labels=c(0.8,1,1.2,1.4,1.6,1.8))  
#最后一个函数的目的在于修改坐标轴的格点，方便美观显示

p<-ggplot(odiff2,aes(x=V2,y=odiff2-1))
p<-p+geom_bar(stat='identity',fill='darkolivegreen3')+
  labs(x='年龄段',y='显瘦销量与非显瘦销量之比',
       title='是否显瘦在每个年龄层的销量比值')+
  theme(text=element_text(family="STKaiti",size=14))
p +scale_y_continuous(limits=c(-0.5, 1.5),breaks=c(-0.5,0,0.5,1,1.5,2),
                      labels=c(0.5,1,1.5,2,2.5,3))
