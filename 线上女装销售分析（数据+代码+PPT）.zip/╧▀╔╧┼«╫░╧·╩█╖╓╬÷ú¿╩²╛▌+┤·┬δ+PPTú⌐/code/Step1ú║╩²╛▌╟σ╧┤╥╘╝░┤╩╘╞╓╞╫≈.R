##############################################
###################写在前面###################
##############################################

#在做所有工作之前，本代码，要安装ggplot2 Rsegword  wordcloud  tm 等包
#很多包对你所用的R的版本可能不兼容，请在网络上搜索并选择合适的方法，来进行安装
#网络上可以搜索到详细的步骤。

#把全部的raw data 放在你的工作空间，由于数据集中很多中文
#本代码在mac上运行无问题，很可能在不同的系统上由于编码的问题会带来不同的问题。
#对于在windows系统上读取数据出现乱码的读者
#在运行之前，将所有的原始数据（.txt） 批量转码成从utf-8转成ANSI，可能会对您的问题有所帮助。

##################################################分割线#####################################

#setwd(#'记得改成你的工作空间')
##批量导入数据，介于数据集的特殊形式，所以选择通过循环变量名来完成导入##
name<-c()         #设置变量名
for (i in 1:98)   
{
  name[i]<-paste0('a',i)   #生成变量形式如 a1, a2
}
for (i in 1:98)
{ k<-paste0('tmall',i,'.txt')   #循环，读取数据tmall1，并赋给a1，如此。
assign(name[i],read.csv(k))
}
#数据集合并
total<-c()
for(i in 1:98){
  total<-rbind(total,get(name[i]))}    #将所有的已读数据集进行合并。

#分析价格:提取价格和销量
#总体
total<-total[which(!is.na(total[,6])),]
price<-total[,6]
sales<-sapply(strsplit(as.character(total[,8]),split='笔'),as.numeric)
#导入文本挖掘相关packages
library(MASS)
library(tm)
library(Rwordseg)
library(wordcloud)
#安装分词所需字典（运行完该语句后记得重启Rstudio方可生效，否则无法识别部分词汇）
installDict('1.txt','1.txt',dicttype = 'text',load=T)

#####准备制作词云#####
goods<-as.character(total[,4])
#删去非中文字符 pattern matching and replacement
goods<-gsub('[a-zA-Z]','',goods)
goods<-gsub('[0-9]','',goods)

segword<-segmentCN(goods) #一个分词函数，根据我们导入的字典，将商品名分割
keyword<-data.frame(table(unlist(segword)))  #统计分割的词语的出现次数

#去除无意义关键词
keyword<-keyword[-which(as.factor(keyword[,1])==c('连衣裙')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('女装')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('女')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('夏')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('夏季')),]
#构造 关键词-出现次数  的数据框
keywords<-data.frame(word=as.character(keyword[,1]),num=keyword[,2])
#选择粉色色系（适合女装主题）
pal <- brewer.pal(6,"Dark2")
pal <- pal[-(1)]
#设置mac os上的中文字体
quartz(family='STKaiti')
par(family='STKaiti')
#绘制词云
wordcloud(family='STKaiti',words = as.character(keyword[,1]),
          freq = keyword$Freq, max.words = 50, random.color = F, colors = pal)
