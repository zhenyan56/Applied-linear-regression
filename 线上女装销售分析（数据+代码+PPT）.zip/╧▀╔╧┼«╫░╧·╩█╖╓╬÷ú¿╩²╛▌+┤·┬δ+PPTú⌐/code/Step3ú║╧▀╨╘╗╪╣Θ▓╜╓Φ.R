###########################################
##############线性回归分析#################
###########################################
##去掉没有描述的商品
totaldes<-total[-which((as.character(total[,13]))==''),]

##以换行分割
s<-as.character(totaldes[,13])
descri<-strsplit(s,split='\n')
##再以冒号分割##
colonspl<-function(x){strsplit(x,split=':')}
sdescri<-sapply(descri,colonspl)
##提取适用年龄##
#判断每一条商品描述里有没有适用年龄
year<-function(x)
{
  as.logical(sum(x=='适用年龄'))
}
whetherold<-function(x){
  sum(sapply(x,year))
}
##把Total 数据集中没有年龄信息的剔除
totalold<-totaldes[which(sapply(sdescri,whetherold)==1),]

#找出年龄
sdescri1<-sapply(unlist(descri),colonspl)
fittedold<-sdescri1[which(sapply(sdescri1,year))]
#提取年龄
old<-as.character(unlist(fittedold))[(1:length(fittedold))*2]
facold<-factor(old)
#######################################################
#######重复对拥有适用年龄的商品进行关键词提取##########
#######################################################
goods<-as.character(totalold[,4])

#删去非中文字符 pattern matching and replacement
goods<-gsub('[0-9]','',goods)

#中文分词
segword<-segmentCN(goods)
keyword<-data.frame(table(unlist(segword)))

#去除无意义关键词
keyword<-keyword[-which(as.factor(keyword[,1])==c('连衣裙')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('女装')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('女')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('夏')),]
keyword<-keyword[-which(as.factor(keyword[,1])==c('夏季')),]

keywords<-data.frame(word=as.character(keyword[,1]),num=keyword[,2])

###逻辑变量回归
facseg<-sapply(segword,as.factor)

hanban<-function(x)
{
  as.logical(sum(x=='韩版')>0)
}
xinkuan<-function(x)
{
  as.logical(sum(x=='新款')>0)
}
xianshou<-function(x)
{
  as.logical(sum(x=='显瘦')>0)
}
xiaji<-function(x)
{
  as.logical(sum(x=='夏季')>0)
}
zhongchang<-function(x)
{
  as.logical(sum(x=='中长款')>0)
}
yinhua<-function(x)
{
  as.logical(sum(x=='印花')>0)
}
xiushen<-function(x){
  as.logical(sum(x=='修身')>0)
}
##从该数据框开始都是log sale 和log price
lgdata6<-data.frame(sales=(log(salesold)),price=log(totalold[,6]),
                    是否韩版=(as.numeric(sapply(facseg,hanban))),
                    是否新款=(as.numeric(sapply(facseg,xinkuan))),
                    是否显瘦=(as.numeric(sapply(facseg,xianshou))),
                    是否中长款=(as.numeric(sapply(facseg,zhongchang))),
                    是否印花=(as.numeric(sapply(facseg,yinhua))),
                    是否修身=(as.numeric(sapply(facseg,xiushen))),
                    old=as.numeric(facold))
###回归
lglm2<-lm(sales~.)
###加交互项   
lglm6<-lm(sales~.+是否韩版*old+
          是否中长款*old+是否印花*old+是否修身*old+是否显瘦*old+是否新款*old
          ,data=lgdata6)
###查看两个回归的结果
summary(lglm2)
summary(lglm6)